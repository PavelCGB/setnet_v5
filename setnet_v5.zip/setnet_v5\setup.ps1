﻿# Локальная сеть + защищённая сеть на одном адаптере (Windows 7, PowerShell 2.0+)
# Запускается через START.bat.
#
# НАСТРОИТЬ:
#  1. Окно с галочками — какие сайты пускать через защищённую сеть.
#  2. Запоминает локальную сеть (IP, маска, шлюз, DNS) в файл на флешке.
#  3. Ставит DHCP + DNS 10.41.129.130 / .131, получает IP/маску/шлюз защищённой сети.
#  4. Возвращает локальную сеть и добавляет второй IP защищённой сети (без шлюза).
#  5. route -p add 10.0.0.0 mask 255.0.0.0 <шлюз защищённой сети>.
#  6. Выбранные сайты -> hosts.
#
# ВЕРНУТЬ НАЗАД:
#  Убирает маршрут, убирает сайты из hosts, оставляет на адаптере только локальную сеть.

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# ============ НАСТРОЙКИ ============
$WorkDNS   = @('10.41.129.130', '10.41.129.131')
$RouteNet  = '10.0.0.0'
$RouteMask = '255.0.0.0'
$DhcpWait  = 60
$DefWorkGW = '10.5.201.254'   # шлюз защищённой сети, если DHCP его не выдал

# Запасные настройки локальной сети (если на компьютере её не найдено)
$DefLocalIP   = '192.168.2.115'
$DefLocalMask = '255.255.252.0'
$DefLocalGW   = '192.168.0.11'
$DefLocalDNS  = @('1.1.1.1', '8.8.8.8')
# ===================================

$sitesFile    = Join-Path $here 'sites.txt'
$selectedFile = Join-Path $here 'selected.txt'
# Бэкапы: папка backups на флешке, один файл на компьютер (по имени ПК)
$backupDir    = Join-Path $here 'backups'
if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir | Out-Null }
$backupFile   = Join-Path $backupDir ("{0}.txt" -f $env:COMPUTERNAME)
# перенос старых файлов local_backup_ИМЯ.txt из корня флешки в папку backups
Get-ChildItem -Path $here -Filter 'local_backup_*.txt' -ErrorAction SilentlyContinue | ForEach-Object {
    $pc = $_.BaseName -replace '^local_backup_', ''
    $dst = Join-Path $backupDir "$pc.txt"
    if (Test-Path $dst) { Remove-Item $_.FullName -Force } else { Move-Item $_.FullName $dst }
}
$hostsPath    = Join-Path $env:windir 'System32\drivers\etc\hosts'
$hostsBegin   = '# >>> WORK-SITES (setup.ps1) >>>'
$hostsEnd     = '# <<< WORK-SITES (setup.ps1) <<<'

function Ok($t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Warn($t) { Write-Host "  [!]  $t" -ForegroundColor Yellow }
function Step($t) { Write-Host ""; Write-Host "== $t" -ForegroundColor Cyan }
function IsV4($s) { return ($s -match '^\d{1,3}(\.\d{1,3}){3}$') }
function GetAd($idx) { return Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "Index=$idx" }
function Check($r, $what) { if ($r.ReturnValue -gt 1) { throw "$what — ошибка, код $($r.ReturnValue)" } }
function CleanName($s) { return ($s.Trim() -replace '^https?://', '' -replace '[:/].*$', '').ToLower() }

# Запуск команды Windows без ложных ошибок PowerShell
$script:LastCode = 0
function Run([string]$cmdline) {
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try {
        $o = & cmd /c "$cmdline 2>&1"
        $script:LastCode = $LASTEXITCODE
        return ($o | Out-String)
    } finally { $ErrorActionPreference = $old }
}
function ToU32($s) { $b = ([System.Net.IPAddress]::Parse($s)).GetAddressBytes(); [Array]::Reverse($b); return [BitConverter]::ToUInt32($b, 0) }
function SameNet($a, $b, $m) { return (((ToU32 $a) -band (ToU32 $m)) -eq ((ToU32 $b) -band (ToU32 $m))) }

function SetStatic($ad, $ips, $masks, $gw, $dns) {
    Check ($ad.EnableStatic([string[]]$ips, [string[]]$masks)) 'Установка IP'
    if ($gw) { Check ($ad.SetGateways([string[]]@($gw), [uint16[]]@(1))) 'Установка шлюза' }
    Check ($ad.SetDNSServerSearchOrder([string[]]$dns)) 'Установка DNS'
}

function SelectAdapter() {
    $physical = @(Get-WmiObject Win32_NetworkAdapter -Filter "PhysicalAdapter=TRUE" | ForEach-Object { $_.Index })
    $ads = @(Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" |
             Where-Object { $physical -contains $_.Index })
    if ($ads.Count -eq 0) { $ads = @(Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE") }
    $real = @($ads | Where-Object { $_.Description -notmatch 'Virtual|Wi-Fi Direct|VPN|Hyper-V|VMware|VirtualBox|Loopback|TAP' })
    if ($real.Count -gt 0) { $ads = $real }
    if ($ads.Count -eq 0) { throw 'Не найден включённый сетевой адаптер. Проверьте кабель.' }
    if ($ads.Count -eq 1) { return $ads[0] }
    Write-Host '  Найдено несколько адаптеров:'
    for ($i = 0; $i -lt $ads.Count; $i++) {
        Write-Host ("   {0}) {1}   [{2}]" -f ($i + 1), $ads[$i].Description, ($ads[$i].IPAddress -join ', '))
    }
    $n = Read-Host '  Номер адаптера, к которому подключён кабель'
    return $ads[[int]$n - 1]
}

# Локальная сеть с адаптера (всё, что не 10.x); $null если не прописана
function ReadLocalFromAdapter($ad) {
    if ($ad.DHCPEnabled) { return $null }
    $l = @{ IP = $null; Mask = $null; GW = $null; DNS = @() }
    for ($i = 0; $i -lt $ad.IPAddress.Count; $i++) {
        $ip = $ad.IPAddress[$i]
        if ((IsV4 $ip) -and -not $ip.StartsWith('10.') -and -not $ip.StartsWith('169.254.')) {
            $l.IP = $ip; $l.Mask = $ad.IPSubnet[$i]; break
        }
    }
    if ($ad.DefaultIPGateway) { $l.GW = @($ad.DefaultIPGateway | Where-Object { (IsV4 $_) -and -not $_.StartsWith('10.') })[0] }
    if ($ad.DNSServerSearchOrder) { $l.DNS = @($ad.DNSServerSearchOrder | Where-Object { $WorkDNS -notcontains $_ }) }
    if ($l.IP -and $l.GW) { return $l }
    return $null
}

function SaveBackup($l) {
    @("PC=$env:COMPUTERNAME", "IP=$($l.IP)", "Mask=$($l.Mask)", "GW=$($l.GW)", "DNS=$($l.DNS -join ',')", "Date=$(Get-Date)") |
        Set-Content $backupFile
}

function LoadBackup() {
    if (-not (Test-Path $backupFile)) { return $null }
    $l = @{ IP = $null; Mask = $null; GW = $null; DNS = @() }
    foreach ($line in @(Get-Content $backupFile)) {
        $k, $v = $line -split '=', 2
        switch ($k) {
            'IP'   { $l.IP = $v }
            'Mask' { $l.Mask = $v }
            'GW'   { $l.GW = $v }
            'DNS'  { $l.DNS = @($v -split ',' | Where-Object { $_ }) }
        }
    }
    if ($l.IP -and $l.GW) { return $l }
    return $null
}

function DefaultLocal() { return @{ IP = $DefLocalIP; Mask = $DefLocalMask; GW = $DefLocalGW; DNS = $DefLocalDNS } }

# Переписать блок рабочих сайтов в hosts (пустой список = убрать блок)
function WriteHosts($entries) {
    if (-not (Test-Path "$hostsPath.bak")) { Copy-Item $hostsPath "$hostsPath.bak"; Ok 'Резервная копия: hosts.bak' }
    $keep = @(); $inBlock = $false
    foreach ($l in @(Get-Content $hostsPath)) {
        if ($l -eq $hostsBegin) { $inBlock = $true; continue }
        if ($l -eq $hostsEnd)   { $inBlock = $false; continue }
        if (-not $inBlock) { $keep += $l }
    }
    while ($keep.Count -gt 0 -and -not ([string]$keep[-1]).Trim()) {
        if ($keep.Count -eq 1) { $keep = @() } else { $keep = @($keep[0..($keep.Count - 2)]) }
    }
    if ($entries.Count -gt 0) { $keep += @('', $hostsBegin) + $entries + @($hostsEnd) }
    Set-Content -Path $hostsPath -Value $keep -Encoding ASCII
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$font = New-Object System.Drawing.Font('Segoe UI', 10)

# ================= ОКНО 1: ЧТО СДЕЛАТЬ =================
$mform = New-Object System.Windows.Forms.Form
$mform.Text = 'Защищённая сеть'
$mform.Size = New-Object System.Drawing.Size(400, 260)
$mform.StartPosition = 'CenterScreen'; $mform.FormBorderStyle = 'FixedDialog'
$mform.MaximizeBox = $false; $mform.MinimizeBox = $false; $mform.TopMost = $true; $mform.Font = $font

$mlbl = New-Object System.Windows.Forms.Label
$mlbl.Text = 'Что сделать?'
$mlbl.Location = New-Object System.Drawing.Point(20, 15); $mlbl.Size = New-Object System.Drawing.Size(350, 25)
$mform.Controls.Add($mlbl)

$bSetup = New-Object System.Windows.Forms.Button
$bSetup.Text = 'Настроить защищённую сеть'
$bSetup.Location = New-Object System.Drawing.Point(20, 50); $bSetup.Size = New-Object System.Drawing.Size(345, 50)
$bSetup.DialogResult = 'Yes'
$mform.Controls.Add($bSetup)

$bRevert = New-Object System.Windows.Forms.Button
$bRevert.Text = 'Вернуть всё назад (только локальная сеть)'
$bRevert.Location = New-Object System.Drawing.Point(20, 110); $bRevert.Size = New-Object System.Drawing.Size(345, 50)
$bRevert.DialogResult = 'No'
$mform.Controls.Add($bRevert)

$bExit = New-Object System.Windows.Forms.Button
$bExit.Text = 'Выход'
$bExit.Location = New-Object System.Drawing.Point(250, 175); $bExit.Size = New-Object System.Drawing.Size(115, 30)
$bExit.DialogResult = 'Cancel'
$mform.Controls.Add($bExit)
$mform.CancelButton = $bExit

$mode = $mform.ShowDialog()
if ($mode -eq 'Cancel') { Write-Host 'Выход. Ничего не изменено.' -ForegroundColor Yellow; return }

# ================= ВЕРНУТЬ НАЗАД =================
if ($mode -eq 'No') {
    $ans = [System.Windows.Forms.MessageBox]::Show(
        "Убрать защищённую сеть и оставить только локальную?`n`nРабочие сайты перестанут открываться.",
        'Вернуть назад', 'YesNo', 'Question')
    if ($ans -ne 'Yes') { Write-Host 'Отменено. Ничего не изменено.' -ForegroundColor Yellow; return }
    try {
        Step 'Ищу сетевой адаптер'
        $ad = SelectAdapter
        Ok $ad.Description

        Step 'Определяю локальную сеть'
        $local = LoadBackup
        if ($local) { Ok "Из бэкапа backups\$env:COMPUTERNAME.txt: $($local.IP) / $($local.Mask), шлюз $($local.GW)" }
        else {
            $local = ReadLocalFromAdapter $ad
            if ($local) { Ok "С адаптера: $($local.IP) / $($local.Mask), шлюз $($local.GW)" }
            else { $local = DefaultLocal; Warn "Не найдена — беру настройки из программы: $($local.IP)" }
        }
        if ($local.DNS.Count -eq 0) { $local.DNS = $DefLocalDNS }

        Step 'Оставляю только локальную сеть'
        SetStatic $ad @($local.IP) @($local.Mask) $local.GW $local.DNS
        Ok "IP $($local.IP) / $($local.Mask), шлюз $($local.GW), DNS $($local.DNS -join ', ')"

        Step 'Убираю маршрут'
        Run "route delete $RouteNet" | Out-Null
        Ok "Маршрут $RouteNet удалён"

        Step 'Убираю рабочие сайты из hosts'
        WriteHosts @()
        Ok 'Готово'
        Run 'ipconfig /flushdns' | Out-Null

        Start-Sleep -Seconds 5
        Step 'Проверка'
        Run 'ping -n 2 -w 1500 1.1.1.1' | Out-Null
        if ($script:LastCode -eq 0) { Ok 'Интернет отвечает' } else { Warn 'Интернет пока не отвечает — подождите минуту' }
        Write-Host ""
        Write-Host 'ВСЁ ВОЗВРАЩЕНО. Перезапустите браузер.' -ForegroundColor Green
    } catch {
        Write-Host ""
        Write-Host ("ОШИБКА: " + $_.Exception.Message) -ForegroundColor Red
        Write-Host 'Если ругается на файл hosts — временно отключите защиту Avast и запустите снова.'
    }
    return
}

# ================= ОКНО 2: ВЫБОР САЙТОВ =================
$reserveMap = @{}
$siteNames = New-Object System.Collections.ArrayList
if (Test-Path $sitesFile) {
    foreach ($line in @(Get-Content $sitesFile)) {
        $t = ($line -split '#')[0].Trim()
        if (-not $t) { continue }
        $parts = @($t -split '\s+')
        $n = CleanName $parts[0]
        if (-not $n -or $siteNames.Contains($n)) { continue }
        [void]$siteNames.Add($n)
        if ($parts.Count -gt 1) { $reserveMap[$n] = $parts[1] }
    }
}
$prevSelected = $null
if (Test-Path $selectedFile) { $prevSelected = @(Get-Content $selectedFile | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }

function SaveSites() {
    $out = @('# Рабочие сайты (список для окна с галочками).',
             '# Одна строка — один сайт. Через пробел можно указать запасной IP.', '')
    foreach ($i in $list.Items) {
        $n = [string]$i
        if ($reserveMap.ContainsKey($n)) { $out += "$n   $($reserveMap[$n])" } else { $out += $n }
    }
    Set-Content -Path $sitesFile -Value $out -Encoding UTF8
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Защищённая сеть — выбор сайтов'
$form.Size = New-Object System.Drawing.Size(460, 470)
$form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false; $form.TopMost = $true; $form.Font = $font

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = 'Отметьте сайты, которые должны открываться через защищённую сеть:'
$lbl.Location = New-Object System.Drawing.Point(12, 10); $lbl.Size = New-Object System.Drawing.Size(420, 40)
$form.Controls.Add($lbl)

$list = New-Object System.Windows.Forms.CheckedListBox
$list.Location = New-Object System.Drawing.Point(12, 52); $list.Size = New-Object System.Drawing.Size(420, 220)
$list.CheckOnClick = $true
foreach ($n in $siteNames) {
    $checked = ($null -eq $prevSelected) -or ($prevSelected -contains $n)
    [void]$list.Items.Add($n, $checked)
}
$form.Controls.Add($list)

$btnAll = New-Object System.Windows.Forms.Button
$btnAll.Text = 'Выбрать все'; $btnAll.Location = New-Object System.Drawing.Point(12, 278); $btnAll.Size = New-Object System.Drawing.Size(130, 30)
$btnAll.Add_Click({ for ($i = 0; $i -lt $list.Items.Count; $i++) { $list.SetItemChecked($i, $true) } })
$form.Controls.Add($btnAll)

$btnNone = New-Object System.Windows.Forms.Button
$btnNone.Text = 'Снять все'; $btnNone.Location = New-Object System.Drawing.Point(148, 278); $btnNone.Size = New-Object System.Drawing.Size(130, 30)
$btnNone.Add_Click({ for ($i = 0; $i -lt $list.Items.Count; $i++) { $list.SetItemChecked($i, $false) } })
$form.Controls.Add($btnNone)

$btnDel = New-Object System.Windows.Forms.Button
$btnDel.Text = 'Удалить'; $btnDel.Location = New-Object System.Drawing.Point(302, 278); $btnDel.Size = New-Object System.Drawing.Size(130, 30)
$btnDel.Add_Click({
    if ($list.SelectedIndex -ge 0) {
        $n = [string]$list.SelectedItem
        $ans = [System.Windows.Forms.MessageBox]::Show("Удалить $n из списка?", 'Удаление', 'YesNo', 'Question')
        if ($ans -eq 'Yes') { $list.Items.RemoveAt($list.SelectedIndex); SaveSites }
    }
})
$form.Controls.Add($btnDel)

$lblAdd = New-Object System.Windows.Forms.Label
$lblAdd.Text = 'Новый сайт (например zdrav.mis66.ru):'
$lblAdd.Location = New-Object System.Drawing.Point(12, 320); $lblAdd.Size = New-Object System.Drawing.Size(420, 22)
$form.Controls.Add($lblAdd)

$txt = New-Object System.Windows.Forms.TextBox
$txt.Location = New-Object System.Drawing.Point(12, 344); $txt.Size = New-Object System.Drawing.Size(284, 26)
$form.Controls.Add($txt)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = 'Добавить'; $btnAdd.Location = New-Object System.Drawing.Point(302, 342); $btnAdd.Size = New-Object System.Drawing.Size(130, 30)
$btnAdd.Add_Click({
    $n = CleanName $txt.Text
    if ($n -and -not $list.Items.Contains($n)) { [void]$list.Items.Add($n, $true); SaveSites }
    $txt.Text = ''; $txt.Focus()
})
$form.Controls.Add($btnAdd)

$btnOk = New-Object System.Windows.Forms.Button
$btnOk.Text = 'Настроить'; $btnOk.Location = New-Object System.Drawing.Point(196, 390); $btnOk.Size = New-Object System.Drawing.Size(115, 32)
$btnOk.DialogResult = 'OK'
$form.Controls.Add($btnOk); $form.AcceptButton = $btnOk

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = 'Отмена'; $btnCancel.Location = New-Object System.Drawing.Point(317, 390); $btnCancel.Size = New-Object System.Drawing.Size(115, 32)
$btnCancel.DialogResult = 'Cancel'
$form.Controls.Add($btnCancel); $form.CancelButton = $btnCancel

$txt.Add_Enter({ $form.AcceptButton = $btnAdd })
$txt.Add_Leave({ $form.AcceptButton = $btnOk })

if ($form.ShowDialog() -ne 'OK') { Write-Host 'Отменено. Ничего не изменено.' -ForegroundColor Yellow; return }
$chosen = @($list.CheckedItems | ForEach-Object { [string]$_ })
if ($chosen.Count -gt 0) { Set-Content -Path $selectedFile -Value $chosen -Encoding UTF8 }
else { Set-Content -Path $selectedFile -Value '' -Encoding UTF8 }
Write-Host ("Выбрано сайтов: {0}" -f $chosen.Count) -ForegroundColor Cyan
foreach ($n in $chosen) { Write-Host "   - $n" }

# ================= НАСТРОЙКА =================
$ad = $null; $local = $null; $restored = $false
try {
    Step 'Ищу сетевой адаптер'
    $ad = SelectAdapter
    $idx = $ad.Index
    Ok $ad.Description

    Step 'Проверяю текущую сеть'
    Write-Host "  Компьютер: $env:COMPUTERNAME"
    $local = ReadLocalFromAdapter $ad
    if ($local) {
        Ok "Сейчас локальная сеть: $($local.IP) / $($local.Mask), шлюз $($local.GW)"
        if ($local.DNS.Count -eq 0) { $local.DNS = $DefLocalDNS }
        if (Test-Path $backupFile) { $how = 'обновлён' } else { $how = 'создан' }
        SaveBackup $local
        Ok ("Бэкап {0}: backups\{1}.txt" -f $how, $env:COMPUTERNAME)
    } else {
        $local = LoadBackup
        if ($local) { Warn "Локальная сеть не прописана — беру бэкап этого ПК: $($local.IP)" }
        else { $local = DefaultLocal; Warn "Локальная сеть не прописана и бэкапа нет — беру настройки из программы: $($local.IP)" }
        if ($local.DNS.Count -eq 0) { $local.DNS = $DefLocalDNS }
    }

    Step 'Получаю настройки защищённой сети по DHCP'
    Check ($ad.EnableDHCP()) 'Включение DHCP'
    Check ((GetAd $idx).SetDNSServerSearchOrder([string[]]$WorkDNS)) 'Установка DNS защищённой сети'
    Start-Sleep -Seconds 3
    Run 'ipconfig /renew' | Out-Null

    $work = $null
    $t0 = Get-Date
    while (((Get-Date) - $t0).TotalSeconds -lt $DhcpWait) {
        $a = GetAd $idx
        if ($a.DHCPEnabled -and $a.IPAddress) {
            for ($i = 0; $i -lt $a.IPAddress.Count; $i++) {
                $ip = $a.IPAddress[$i]; $mask = $a.IPSubnet[$i]
                if ((IsV4 $ip) -and -not $ip.StartsWith('169.254.') -and $ip -ne $local.IP) {
                    # шлюз берём только из той же подсети, что и полученный адрес
                    $gw = $null
                    if ($a.DefaultIPGateway) {
                        $gw = @($a.DefaultIPGateway | Where-Object { (IsV4 $_) -and (SameNet $_ $ip $mask) })[0]
                    }
                    $work = @{ IP = $ip; Mask = $mask; GW = $gw }
                    break
                }
            }
        }
        if ($work -and $work.GW) { break }
        Write-Host '  ...жду ответ DHCP'
        Start-Sleep -Seconds 3
    }
    if (-not $work) { throw "Защищённая сеть не выдала адрес за $DhcpWait сек." }
    if (-not $work.GW) {
        if (SameNet $DefWorkGW $work.IP $work.Mask) {
            $work.GW = $DefWorkGW
            Warn "DHCP не выдал шлюз — беру из настроек: $DefWorkGW"
        } else { throw "Не удалось определить шлюз защищённой сети (адрес $($work.IP))." }
    }
    Ok "Защищённая сеть: $($work.IP) / $($work.Mask), шлюз $($work.GW)"

    Step 'Возвращаю локальную сеть и добавляю защищённую'
    $dns = @($local.DNS) + @($WorkDNS | Where-Object { $local.DNS -notcontains $_ })
    SetStatic (GetAd $idx) @($local.IP, $work.IP) @($local.Mask, $work.Mask) $local.GW $dns
    $restored = $true
    Ok "IP: $($local.IP) и $($work.IP)"
    Ok "Шлюз (интернет): $($local.GW)"
    Ok ("DNS: " + ($dns -join ', '))
    Write-Host '  Жду, пока сеть применит настройки...'
    Start-Sleep -Seconds 8

    Step 'Прописываю маршрут'
    Run "route delete $RouteNet" | Out-Null
    Run "route -p add $RouteNet mask $RouteMask $($work.GW)" | Out-Null
    if ($script:LastCode -ne 0) { throw 'Команда route завершилась с ошибкой.' }
    Ok "route -p add $RouteNet mask $RouteMask $($work.GW)"

    Step 'Узнаю адреса выбранных сайтов'
    $entries = @()
    foreach ($name in $chosen) {
        $ip = $null
        foreach ($srv in $WorkDNS) {
            $out = Run "nslookup -timeout=3 $name $srv"
            $found = @([regex]::Matches($out, '\b\d{1,3}(?:\.\d{1,3}){3}\b') |
                       ForEach-Object { $_.Value } | Where-Object { $WorkDNS -notcontains $_ })
            if ($found.Count -gt 0) { $ip = $found[0]; break }
        }
        if ($ip) { Ok "$name -> $ip" }
        elseif ($reserveMap.ContainsKey($name)) { $ip = $reserveMap[$name]; Warn "$name : DNS не ответил, беру запасной $ip" }
        else { Warn "$name : адрес не найден, пропускаю"; continue }
        $entries += ("{0}`t{1}" -f $ip, $name)
    }

    Step 'Записываю сайты в hosts'
    WriteHosts $entries
    Ok "В hosts прописано сайтов: $($entries.Count) (снятые галочки убраны)"
    Run 'ipconfig /flushdns' | Out-Null
    Ok 'Кэш DNS очищен'

    Step 'Проверка'
    foreach ($p in @(@('1.1.1.1', 'Интернет'), @($WorkDNS[0], 'Защищённая сеть'))) {
        Run "ping -n 2 -w 1500 $($p[0])" | Out-Null
        if ($script:LastCode -eq 0) { Ok "$($p[1]) ($($p[0])) — отвечает" }
        else { Warn "$($p[1]) ($($p[0])) — НЕ отвечает" }
    }
    Write-Host ""
    Write-Host 'ГОТОВО. Перезапустите браузер.' -ForegroundColor Green
}
catch {
    Write-Host ""
    Write-Host ("ОШИБКА: " + $_.Exception.Message) -ForegroundColor Red
    if ($ad -and $local -and $local.IP -and -not $restored) {
        Write-Host '  Возвращаю локальную сеть как было...' -ForegroundColor Yellow
        try {
            SetStatic (GetAd $ad.Index) @($local.IP) @($local.Mask) $local.GW $local.DNS
            Ok 'Локальная сеть восстановлена'
        } catch { Warn 'Не удалось восстановить. Настройки лежат на флешке в backups\$env:COMPUTERNAME.txt' }
    }
    Write-Host 'Если ругается на файл hosts — временно отключите защиту Avast и запустите снова.'
}
