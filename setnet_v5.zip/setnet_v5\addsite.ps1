﻿# ДОБАВИТЬ САЙТ — быстро добавить рабочий сайт в защищённую сеть (Windows 7/10/11)
# Запускается через ADD_SITE.bat. Сеть не перенастраивает:
#   узнаёт IP сайта у рабочего DNS -> пишет в hosts -> проверяет -> открывает.
# Сайт также добавляется в sites.txt (галочки в START.bat).

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# ============ НАСТРОЙКИ ============
$WorkDNS = @('10.41.129.130', '10.41.129.131')
# ===================================

$sitesFile    = Join-Path $here 'sites.txt'
$selectedFile = Join-Path $here 'selected.txt'
$hostsPath    = Join-Path $env:windir 'System32\drivers\etc\hosts'
$hostsBegin   = '# >>> WORK-SITES (setup.ps1) >>>'
$hostsEnd     = '# <<< WORK-SITES (setup.ps1) <<<'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------- вспомогательное ----------
function Run([string]$cmdline) {
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $o = & cmd /c "$cmdline 2>&1"; $script:LastCode = $LASTEXITCODE; return ($o | Out-String) }
    finally { $ErrorActionPreference = $old }
}
function CleanName($s) { return ($s.Trim().ToLower() -replace '^https?://', '' -replace '[:/].*$', '' -replace '\s', '') }
function GetPort($s) {
    $t = $s.Trim().ToLower()
    if ($t -match '^[a-z]+://[^/:]+:(\d+)' -or $t -match '^[^/:]+:(\d+)') { return [int]$matches[1] }
    if ($t.StartsWith('http://')) { return 80 }
    return 0   # неизвестно — проверим 443 и 80
}
function MakeUrl($s) {
    $t = $s.Trim()
    if ($t -match '^[a-zA-Z]+://') { return $t }
    if ($t -match '^[^/:]+:(\d+)') { if ($matches[1] -eq '443') { return "https://$t" } else { return "http://$t" } }
    return "https://$t"
}
function ResolveSite($name) {
    foreach ($srv in $WorkDNS) {
        $out = Run "nslookup -timeout=3 $name $srv"
        $found = @([regex]::Matches($out, '\b\d{1,3}(?:\.\d{1,3}){3}\b') |
                   ForEach-Object { $_.Value } | Where-Object { $WorkDNS -notcontains $_ })
        if ($found.Count -gt 0) { return $found[0] }
    }
    return $null
}
function TestPort($ip, $port) {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $c.BeginConnect($ip, $port, $null, $null)
        $ok = $ar.AsyncWaitHandle.WaitOne(2500, $false)
        return ($ok -and $c.Connected)
    } catch { return $false } finally { $c.Close() }
}
function WorkNetUp() {
    foreach ($d in $WorkDNS) { Run "ping -n 1 -w 1500 $d" | Out-Null; if ($script:LastCode -eq 0) { return $true } }
    return $false
}

# ---------- hosts: блок рабочих сайтов ----------
function ReadBlock() {
    $map = @{}
    if (-not (Test-Path $hostsPath)) { return $map }
    $in = $false
    foreach ($l in @(Get-Content $hostsPath)) {
        if ($l -eq $hostsBegin) { $in = $true; continue }
        if ($l -eq $hostsEnd)   { $in = $false; continue }
        if ($in) {
            $p = @(($l -split '#')[0].Trim() -split '\s+')
            if ($p.Count -ge 2 -and $p[0]) { $map[$p[1].ToLower()] = $p[0] }
        }
    }
    return $map
}
function WriteBlock($map) {
    if (-not (Test-Path "$hostsPath.bak")) { Copy-Item $hostsPath "$hostsPath.bak" }
    $keep = @(); $in = $false
    foreach ($l in @(Get-Content $hostsPath)) {
        if ($l -eq $hostsBegin) { $in = $true; continue }
        if ($l -eq $hostsEnd)   { $in = $false; continue }
        if (-not $in) { $keep += $l }
    }
    while ($keep.Count -gt 0 -and -not ([string]$keep[-1]).Trim()) {
        if ($keep.Count -eq 1) { $keep = @() } else { $keep = @($keep[0..($keep.Count - 2)]) }
    }
    if ($map.Count -gt 0) {
        $keep += @('', $hostsBegin)
        foreach ($k in ($map.Keys | Sort-Object)) { $keep += ("{0}`t{1}" -f $map[$k], $k) }
        $keep += $hostsEnd
    }
    Set-Content -Path $hostsPath -Value $keep -Encoding ASCII
}

# ---------- sites.txt / selected.txt ----------
function AddToLists($name, $ip) {
    $names = @()
    if (Test-Path $sitesFile) {
        foreach ($line in @(Get-Content $sitesFile)) {
            $t = ($line -split '#')[0].Trim()
            if ($t) { $names += (CleanName (@($t -split '\s+')[0])) }
        }
    }
    if ($names -notcontains $name) {
        if (-not (Test-Path $sitesFile)) {
            Set-Content -Path $sitesFile -Encoding UTF8 -Value @('# Рабочие сайты (список для окна с галочками).', '')
        }
        Add-Content -Path $sitesFile -Encoding UTF8 -Value ("{0}   {1}" -f $name, $ip)
    }
    if (Test-Path $selectedFile) {
        $sel = @(Get-Content $selectedFile | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($sel -notcontains $name) { Set-Content -Path $selectedFile -Encoding UTF8 -Value ($sel + $name) }
    }
}
function RemoveFromSelected($name) {
    if (Test-Path $selectedFile) {
        $sel = @(Get-Content $selectedFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -ne $name })
        if ($sel.Count -gt 0) { Set-Content -Path $selectedFile -Encoding UTF8 -Value $sel }
        else { Set-Content -Path $selectedFile -Encoding UTF8 -Value '' }
    }
}

# ================= ОКНО =================
$font = New-Object System.Drawing.Font('Segoe UI', 10)
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Добавить рабочий сайт'
$form.Size = New-Object System.Drawing.Size(560, 560)
$form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false; $form.TopMost = $true; $form.Font = $font

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = 'Адрес сайта (можно скопировать из браузера целиком):'
$lbl.Location = New-Object System.Drawing.Point(12, 12); $lbl.Size = New-Object System.Drawing.Size(520, 22)
$form.Controls.Add($lbl)

$txt = New-Object System.Windows.Forms.TextBox
$txt.Location = New-Object System.Drawing.Point(12, 38); $txt.Size = New-Object System.Drawing.Size(380, 26)
$form.Controls.Add($txt)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = 'Добавить'; $btnAdd.Location = New-Object System.Drawing.Point(400, 36); $btnAdd.Size = New-Object System.Drawing.Size(132, 30)
$form.Controls.Add($btnAdd); $form.AcceptButton = $btnAdd

$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true; $log.ReadOnly = $true; $log.ScrollBars = 'Vertical'
$log.Location = New-Object System.Drawing.Point(12, 76); $log.Size = New-Object System.Drawing.Size(520, 170)
$log.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($log)

$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text = 'Открыть сайт'; $btnOpen.Location = New-Object System.Drawing.Point(12, 252); $btnOpen.Size = New-Object System.Drawing.Size(150, 30)
$btnOpen.Enabled = $false
$form.Controls.Add($btnOpen)

$lbl2 = New-Object System.Windows.Forms.Label
$lbl2.Text = 'Сейчас через защищённую сеть открываются:'
$lbl2.Location = New-Object System.Drawing.Point(12, 296); $lbl2.Size = New-Object System.Drawing.Size(520, 22)
$form.Controls.Add($lbl2)

$list = New-Object System.Windows.Forms.ListBox
$list.Location = New-Object System.Drawing.Point(12, 320); $list.Size = New-Object System.Drawing.Size(380, 150)
$form.Controls.Add($list)

$btnDel = New-Object System.Windows.Forms.Button
$btnDel.Text = 'Убрать'; $btnDel.Location = New-Object System.Drawing.Point(400, 320); $btnDel.Size = New-Object System.Drawing.Size(132, 30)
$form.Controls.Add($btnDel)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = 'Закрыть'; $btnClose.Location = New-Object System.Drawing.Point(400, 482); $btnClose.Size = New-Object System.Drawing.Size(132, 30)
$btnClose.DialogResult = 'Cancel'
$form.Controls.Add($btnClose); $form.CancelButton = $btnClose

$script:lastUrl = $null

function Say($t) { $log.AppendText($t + "`r`n"); [System.Windows.Forms.Application]::DoEvents() }
function RefreshList() {
    $list.Items.Clear()
    $map = ReadBlock
    foreach ($k in ($map.Keys | Sort-Object)) { [void]$list.Items.Add(("{0}   ({1})" -f $k, $map[$k])) }
}

$btnAdd.Add_Click({
    $raw = $txt.Text
    $name = CleanName $raw
    $log.Clear(); $btnOpen.Enabled = $false
    if (-not $name -or $name -notmatch '\.') { Say 'Введите адрес сайта, например dlo.mis66.ru'; return }
    $form.Cursor = 'WaitCursor'; $btnAdd.Enabled = $false
    try {
        Say "Сайт: $name"
        Say 'Проверяю защищённую сеть...'
        if (-not (WorkNetUp)) {
            Say '[!] Защищённая сеть не отвечает на этом компьютере.'
            Say '    Сначала запустите START.bat -> «Настроить защищённую сеть».'
            return
        }
        Say '[OK] Защищённая сеть работает'

        Say 'Узнаю адрес у рабочего DNS...'
        $ip = ResolveSite $name
        if (-not $ip) {
            Say "[!] Рабочий DNS не знает сайт $name."
            Say '    Проверьте, правильно ли написан адрес.'
            return
        }
        Say "[OK] $name -> $ip"
        if (-not $ip.StartsWith('10.')) {
            Say "[!] Адрес $ip не из защищённой сети (не 10.x) — это обычный интернет-сайт,"
            Say '    добавлять его не нужно, он и так должен открываться.'
            return
        }

        $map = ReadBlock
        $map[$name] = $ip
        WriteBlock $map
        AddToLists $name $ip
        Run 'ipconfig /flushdns' | Out-Null
        Say '[OK] Прописан в hosts и добавлен в список сайтов'

        Say 'Проверяю, отвечает ли сайт...'
        $port = GetPort $raw
        $ports = @(); if ($port -gt 0) { $ports = @($port) } else { $ports = @(443, 80) }
        $alive = $false
        foreach ($p in $ports) { if (TestPort $ip $p) { $alive = $true; Say "[OK] Сайт отвечает (порт $p)"; break } }
        if (-not $alive) { Say "[!] Адрес прописан, но сайт не ответил (порт $($ports -join ', ')). Попробуйте открыть." }

        $script:lastUrl = MakeUrl $raw
        $btnOpen.Enabled = $true
        Say ''
        Say 'ГОТОВО. Если браузер был открыт — обновите страницу (F5).'
        RefreshList
        $txt.Text = ''
    } catch {
        Say ("ОШИБКА: " + $_.Exception.Message)
        Say 'Если ругается на файл hosts — временно отключите защиту антивируса (Avast).'
    } finally {
        $form.Cursor = 'Default'; $btnAdd.Enabled = $true
    }
})

$btnOpen.Add_Click({ if ($script:lastUrl) { Start-Process $script:lastUrl } })

$btnDel.Add_Click({
    if ($list.SelectedIndex -lt 0) { return }
    $name = (([string]$list.SelectedItem) -split '\s+')[0]
    $ans = [System.Windows.Forms.MessageBox]::Show("Убрать $name из защищённой сети на этом компьютере?", 'Убрать сайт', 'YesNo', 'Question')
    if ($ans -ne 'Yes') { return }
    try {
        $map = ReadBlock; $map.Remove($name); WriteBlock $map
        RemoveFromSelected $name
        Run 'ipconfig /flushdns' | Out-Null
        $log.Clear(); Say "[OK] $name убран (в списке sites.txt остался — галочку можно поставить снова в START.bat)"
        RefreshList
    } catch { Say ("ОШИБКА: " + $_.Exception.Message) }
})

RefreshList
[void]$form.ShowDialog()
